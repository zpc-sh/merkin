Pactis LGI — Language Gateway Interface

Overview
- Purpose: a stable, vendor-agnostic interface for AI interactions (chat, tools, LSP-ish operations) exposed via HTTP and internally via a thin client.
- Goals: deterministic versioning with Ash-style Events, observability, and consistent safety controls regardless of provider.

Guiding Principles
- Event-first: every interaction emits versioned events; state is derived from events.
- Vendor-agnostic: requests are normalized and routed; providers can change without clients.
- Safe-by-default: rate limits, redaction, and policy checks applied before provider calls.
- Minimal surface: small, composable operations (chat, tool.invoke, tool.describe, session lifecycle).

Event Model (AshEvents)
- LGI.Event.V1.ToolDeclared: publish a tool’s schema and capabilities.
- LGI.Event.V1.ToolInvoked: record an invocation request (idempotent key, actor, inputs).
- LGI.Event.V1.ToolResult: record the resolved result (success/error, outputs, latency, cost).
- LGI.Event.V1.ChatStarted/ChatMessage/ChatCompleted: capture conversational sequences.
- LGI.Event.V1.ModelCallStarted/ModelCallCompleted: lower-level provider call details for auditing.
- LGI.Event.V1.PolicyDecision: record allow/deny with rule references and redactions performed.

Versioning
- Major versions reflect shape changes to events and request/response schemas.
- Producers emit both canonical events and provider-specific extras under `meta.provider`.
- Consumers rely on canonical fields; extras are optional/extensible.

HTTP Surface (initial)
- GET `/api/v1/lgi/spec`: returns the LGI OpenAPI snippet and event catalog with current versions.
- GET `/api/v1/lgi/tools`: lists available tools with JSON Schema definitions.
- POST `/api/v1/lgi/execute`: invokes a tool. Body: `{tool: string, input: map, context?: map}`. Emits ToolInvoked/ToolResult.
- POST `/api/v1/lgi/chat`: simple chat completion. Body: `{messages: [...], options?: map}`. Emits ChatStarted/ChatCompleted and ModelCall events.

Internal Client
- `Pactis.AI.ReqClient` is the only allowed transport for model calls; it wraps `req_llm` for vendor-neutral access.
- Services call `Pactis.AI.ReqClient.chat/2` and `...tool_call/3` instead of hitting providers directly.
- Router-level heuristics and caching remain orthogonal; enforcement is at the boundary.

Policies & Enforcement
- Pre-call hooks: redact secrets, apply per-tenant rate limits, reject disallowed tools/models.
- Transport enforcement: forbid direct HTTP calls to vendor endpoints in services; emit deprecation warnings in legacy providers; add static check (CI) later.

Observability
- Each request logs correlation id, actor, tenant, tool/model, token counts, and latency.
- Costs are estimated via router and recorded alongside events.

LSP-Like Bridge (future)
- WebSocket streaming channel for `delta` events (tokens, tool streaming, trace spans).
- Backed by the same event stream so replay is possible.

OpenAPI Sketch
- Components: Tool, ToolInput (JSON Schema), ChatMessage, ChatOptions, LGIEvent.
- Paths mirror endpoints above; responses include `event_ids` for correlation.

Security Notes
- Inputs pass through validation against tool schemas.
- Outputs are capped/filtered; JSON-only mode preferred for tool invocations.
- Audit trail enforced by required event emission for every call.

Migration Plan
- Phase 1: Ship endpoints + `ReqClient`; emit minimal events (in-memory/log for now).
- Phase 2: Persist Ash-style events and wire PubSub; add OpenAPI.
- Phase 3: Introduce WS streaming and richer policies.

