# Pactis Framework — Standards Track RFC

Status: draft
Notice: Pactis™ is an open specification by Pactis and is not affiliated with any other entity using similar names. ™ indicates an unregistered trademark claim.
Aliases: formerly referred to as “Pactum Framework (PF)” and “Truth Negotiation Framework (TNF)” in earlier docs.

Recommended naming
- Umbrella (Standards Track): Pactis Framework
  - Rationale: “Pactis” (plural of pactum) emphasizes negotiated agreement without implying transport, matching the JSON‑LD data model, invariants, and guarantees (idempotency, determinism, provenance).

Layering model
- Pactis (framework): Defines canonical JSON‑LD shapes (Blueprint, ArtifactPointer, Generator, Provenance), context policy, validation taxonomy, determinism, and conformance. No network coupling mandated.
- Profiles (wire‑level “interfaces” within Pactis): Each specifies an API/contract for a specific function. Use “Interface” to avoid ambiguity:
  - Pactis‑TVI: Truth Validation Interface (validation API responses + error taxonomy)
  - Pactis‑GRI: Generator Registry Interface (capabilities, versions)
  - Pactis‑API: Artifact Publication Interface (enroll, generate, fetch artifacts)
  - Pactis‑VFS: Artifact File Serving Profile (CAS/VFS access semantics)

RFC Outline

## Abstract
Define “negotiated truth”: converging a negotiated truth from authored JSON‑LD via validation, producing signed, deterministic, content‑addressed artifacts.

## Terminology & Normative Language
Define key terms (Blueprint, ArtifactPointer, GeneratorDescriptor, ValidationReport, Provenance), RFC‑2119/8174 normative language.

## Context Policy
- Allowed prefixes and versioning rules.
- Context pinning and freshness guarantees.
- Backwards/forwards compatibility guidance.

## JSON‑LD Shapes (normative)
- Blueprint: required keys; examples.
- ArtifactPointer: immutable; CAS digests; signing; examples.
- GeneratorDescriptor: capabilities, inputs, semver.
- ValidationReport: error taxonomy structure.

## Validation Tiers
- Syntax → Schema → Policy.
- Error codes and machine‑friendly forms.

## Determinism & Idempotency Guarantees
- Input set → unique pointer and CAS digests.
- Idempotent key = (source_id, framework, generator_version).

## Provenance & Signing
- ed25519 over canonicalized JSON (URDNA2015 baseline) using W3C Data Integrity.
- Verification requirements and failure modes.

## Conformance
- Golden vectors.
- Determinism checks.
- Error taxonomy conformance.
- Signature verification conformance.

## Security Considerations
- Tampering, stale contexts, supply chain, signature spoofing.

## Profiles Index
Pointers to interface specs:
- Pactis‑TVI: docs/specifications/Pactis-TVI.md
- Pactis‑GRI: docs/specifications/Pactis-GRI.md
- Pactis‑API: docs/specifications/Pactis-API.md
- Pactis‑VFS: docs/specifications/Pactis-VFS.md

## Context & Prefixes
- Preferred JSON‑LD context: `/jsonld/pactis.context.jsonld`
- Vocab base: `https://pactis.dev/vocab/`
- QName prefix: use `pactis:` for terms and IDs, for example:
  - `"@id": "pactis:components/button-primary"`
  - `"@type": "pactis:TokenSet"`
  - `"pactis:validatedAgainst": ["pactis:policy/color-contrast"]`
- When embedding Pactis terms in other graphs, include the context or map `pactis` to the vocab URL.
