# Pactis‑API: Artifact Publication Interface

Status: draft
Notice: Pactis™ is an open specification by Pactis and is not affiliated with any other entity using similar names. ™ indicates an unregistered trademark claim.

## Purpose
Enroll sources, request generation, and fetch artifacts and pointers without mandating storage or transport coupling.

## Scope
- Enroll source; request generation by GeneratorDescriptor; retrieve ArtifactPointer and artifacts.

## API Sketch
- POST /enroll: register source with context policy.
- POST /generate: inputs + generator_version → ArtifactPointer.
- GET /artifacts/{pointer}: fetch immutable artifact (CAS semantics).

## Conformance
- Idempotency keys; determinism checks; pointer immutability.
