# Pactis‑SRI: Service Registry Interface

Status: draft

## Purpose
Allow each code repository or service to publish a canonical JSON‑LD service manifest. A registry API aggregates manifests across repos to drive the public website, status, and discovery.

## Shape: `pactis:ServiceDescriptor`
- `@id`: stable service IRI (`pactis:service/{name}`)
- `@type`: [`pactis:ServiceDescriptor`, `schema:Service`]
- `name`: human title
- `description`: short description/marketing copy
- `version`: semver
- `homepage`, `documentation`, `statusPage`, `spec`
- `api`:
  - `openapi`: path or URL
  - `jsonapi`: path or URL
  - `manifests[]`: `{ rel, href, type }` (e.g., context, service)
- `branding`:
  - `logo`: URL or `schema:ImageObject` with integrity
  - `theme`: optional `schema:MediaObject` for a CSS theme
  - `favicon`, `themeColor`
- `contact`:
  - `supportEmail`, `securityEmail`, `twitter`, `github`
- `links[]`: `{ rel, href, title? }`
- `runtime` (optional): `{ region, environment, commit, buildAt }`
- `provenance` (optional): PROV‑O relations

## Context
- `/jsonld/pactis.context.jsonld` + `schema` prefix (https://schema.org/)

## File Location
- Recommended path: `priv/service.manifest.jsonld` in each repository.
- Public endpoint: `GET /service.jsonld` (served directly from `priv`).
- Optional discovery aliases:
  - `GET /.well-known/pactis/service.jsonld` — well‑known for crawlers
  - Vanity paths (organization-specific), e.g., `GET /zpc/avici/service` — MUST serve the same manifest

## Aggregation API
- Registry accepts one or more sources:
  - Git repositories (read `priv/service.manifest.jsonld` at HEAD or by tag)
  - HTTP endpoints (`https://service.example.com/service.jsonld`)
- Output: merged JSON‑LD graph of `pactis:ServiceDescriptor` nodes.
- Suggested endpoint: `GET /api/v1/services` returning `[ServiceDescriptor]` as JSON‑LD.

## Validation (TVI)
- Syntax/schema: validate required keys; URLs reachable (optional); email format.
- Policy: `@id` uniqueness; version semver; `openapi` resolves.
- Determinism: canonicalize and sign if desired (Data Integrity proof) to support provenance.

## Example
See `priv/service.manifest.jsonld` in this repository as a reference template.

Example with integrity metadata:

```
{
  "@context": [
    "/jsonld/pactis.context.jsonld",
    { "schema": "https://schema.org/", "specs": "https://specs.pactis.dev/vocab/" }
  ],
  "@id": "pactis:service/pactis",
  "@type": ["pactis:ServiceDescriptor", "schema:Service"],
  "name": "Pactis Framework",
  "branding": {
    "logo": {
      "@type": "schema:ImageObject",
      "contentUrl": "/cas/sha256/2f64...ab.svg",
      "encodingFormat": "image/svg+xml",
      "sha256": "2f64...ab"
    },
    "theme": {
      "@type": "schema:MediaObject",
      "contentUrl": "/cas/sha256/9c21...ff.css",
      "encodingFormat": "text/css",
      "sha256": "9c21...ff"
    },
    "themeColor": "#FD4F00"
  }
}
```

## Notes
- For multi‑tenant or multi‑region deployments, use an array of `runtime` entries or variant manifests.
- Consider versioned contexts for long‑term cache stability (e.g., `/jsonld/pactis.context.v1.jsonld`).
