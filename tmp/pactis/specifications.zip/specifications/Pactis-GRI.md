# Pactis‑GRI: Generator Registry Interface

Status: draft
Notice: Pactis™ is an open specification by Pactis and is not affiliated with any other entity using similar names. ™ indicates an unregistered trademark claim.

## Purpose
Advertise and resolve generator capabilities, inputs, and versions used to produce deterministic artifacts.

## Scope
- Query capabilities; fetch GeneratorDescriptor; resolve semver ranges to exact versions.

## API Sketch
- GET /generators: list with capabilities and versions.
- GET /generators/{id}: GeneratorDescriptor.

## Conformance
- Stable identifiers; semver discipline; provenance linkage to artifacts.
